import { useState } from 'react';

export default function Dashboard() {
  const [tasks, setTasks] = useState({
    workout: false,
    facialCareAM: false,
    facialCarePM: false,
    journaling: false,
    deepClean: false,
  });

  const toggleTask = (task) => {
    setTasks({ ...tasks, [task]: !tasks[task] });
  };

  const completedCount = Object.values(tasks).filter(Boolean).length;
  const progress = (completedCount / Object.keys(tasks).length) * 100;

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>🌙 Night Shift Tracker</h1>
      <p>Daily Progress: {completedCount} / {Object.keys(tasks).length}</p>
      <progress value={progress} max="100" style={{ width: '100%' }}></progress>

      {Object.keys(tasks).map((task) => (
        <div key={task} style={{ margin: '10px 0' }}>
          <label>
            <input type="checkbox" checked={tasks[task]} onChange={() => toggleTask(task)} />
            {' ' + task.replace(/([A-Z])/g, ' $1')}
          </label>
        </div>
      ))}
    </div>
  );
}